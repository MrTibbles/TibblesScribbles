define(['jquery', 'backbone'], function($, Backbone) {
  var dealer = Backbone.Model.extend({});
  return dealer;
})