define(['jquery', 'backbone'], function($, Backbone) {
  var repair = Backbone.Model.extend({});
  return repair;
})