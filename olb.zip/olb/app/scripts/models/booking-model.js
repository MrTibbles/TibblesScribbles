define(['jquery', 'backbone'], function($, Backbone) {
  var booking = Backbone.Model.extend({});
  return booking;
})