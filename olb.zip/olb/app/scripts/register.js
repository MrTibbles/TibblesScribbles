define([], function() {
	//passign instances of models for backbone relational
  return {};
});